package tresraya.tresenraya;

public class Tablero {

    private String[][] tablero;
    
    public Tablero() {
        tablero = new String[3][3];
        reiniciar();
    }

    public void reiniciar() {
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                tablero[fila][columna] = "-";
            }
        }
    }

public void mostrarTablero() {
    for (int fila = 0; fila < 3; fila++) {
        for (int columna = 0; columna < 3; columna++) {
            System.out.print(tablero[fila][columna] + " ");
        }
        System.out.println();
    }
}

    public boolean marcar(int fila, int columna, Jugador jugador) {
        if (tablero[fila-1][columna-1].equals("-")) {
            tablero[fila-1][columna-1] = jugador.getMarca();
            return true;
        } else {
            return false;
        }
    }

    public boolean hayGanador(Jugador jugador) {
        String marca = jugador.getMarca();
        for (int i = 0; i < 3; i++) {
            if (tablero[i][0].equals(marca) && tablero[i][1].equals(marca) && tablero[i][2].equals(marca)) {
                return true;
            }
            if (tablero[0][i].equals(marca) && tablero[1][i].equals(marca) && tablero[2][i].equals(marca)) {
                return true;
            }
        }
        if (tablero[0][0].equals(marca) && tablero[1][1].equals(marca) && tablero[2][2].equals(marca)) {
            return true;
        }
        if (tablero[0][2].equals(marca) && tablero[1][1].equals(marca) && tablero[2][0].equals(marca)) {
            return true;
        }
        return false;
    }

    public boolean estaLleno() {
        for (int fila = 0; fila < 3; fila++) {
            for (int columna = 0; columna < 3; columna++) {
                if (tablero[fila][columna].equals("-")) {
                    return false;
                }
            }
        }
        return true;
    }

}
    
