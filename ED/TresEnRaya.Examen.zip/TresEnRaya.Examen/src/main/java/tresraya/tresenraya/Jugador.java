package tresraya.tresenraya;

public class Jugador {
    private String marca;
    
    public Jugador(String marca) {
        this.marca = marca;
    }
    
    public String getMarca() {
        return marca;
    }
}




