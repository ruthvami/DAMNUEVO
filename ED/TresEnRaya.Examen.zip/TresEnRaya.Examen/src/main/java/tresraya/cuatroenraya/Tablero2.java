package tresraya.cuatroenraya;

import tresraya.tresenraya.*;

public class Tablero2 {

    private String[][] tablero2;
    
    public Tablero2() {
        tablero2 = new String[6][7];
        reiniciar();
    }

    public void reiniciar() {
        for (int fila = 0; fila < 6; fila++) {
            for (int columna = 0; columna < 7; columna++) {
                tablero2[fila][columna] = "-";
            }
        }
    }

public void mostrarTablero() {
    for (int fila = 0; fila < 6; fila++) {
        for (int columna = 0; columna < 7; columna++) {
            System.out.print(tablero2[fila][columna] + " ");
        }
        System.out.println();
    }
}

    public boolean marcar(int fila, int columna, Jugador jugador) {
        if (tablero2[fila-1][columna-1].equals("-")) {
            tablero2[fila-1][columna-1] = jugador.getMarca();
            return true;
        } else {
            return false;
        }
    }

public boolean hayGanador(Jugador jugador) {
    String marca = jugador.getMarca();
    // Comprobar las filas
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 4; j++) {
            if (tablero2[i][j].equals(marca) && tablero2[i][j+1].equals(marca) && tablero2[i][j+2].equals(marca) && tablero2[i][j+3].equals(marca)) {
                return true;
            }
        }
    }
    // Comprobar las columnas
    for (int i = 0; i < 7; i++) {
        for (int j = 0; j < 3; j++) {
            if (tablero2[j][i].equals(marca) && tablero2[j+1][i].equals(marca) && tablero2[j+2][i].equals(marca) && tablero2[j+3][i].equals(marca)) {
                return true;
            }
        }
    }
    // Comprobar diagonales descendentes
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            if (tablero2[i][j].equals(marca) && tablero2[i+1][j+1].equals(marca) && tablero2[i+2][j+2].equals(marca) && tablero2[i+3][j+3].equals(marca)) {
                return true;
            }
        }
    }
    // Comprobar diagonales ascendentes
    for (int i = 3; i < 6; i++) {
        for (int j = 0; j < 4; j++) {
            if (tablero2[i][j].equals(marca) && tablero2[i-1][j+1].equals(marca) && tablero2[i-2][j+2].equals(marca) && tablero2[i-3][j+3].equals(marca)) {
                return true;
            }
        }
    }
    return false;
}


    public boolean estaLleno() {
        for (int fila = 0; fila < 6; fila++) {
            for (int columna = 0; columna < 7; columna++) {
                if (tablero2[fila][columna].equals("-")) {
                    return false;
                }
            }
        }
        return true;
    }

}
    
